package edu.upc.dsa.app_usando_retrofit_victor;

public class Repo {
    private String name;
    private int  id;

    public String getName() {
        return name;
    }
    public int getId() {
        return id;
    }
    }


